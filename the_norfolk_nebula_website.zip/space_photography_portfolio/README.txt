# Jonathan Lanchester Space Photography

A responsive one-page astrophotography portfolio.

## Quick start
Open `index.html` in a web browser.

## Customising
- Replace `assets/hero-placeholder.png` with your own photograph.
- Edit the text in `index.html`.
- To add real gallery images, replace the CSS card backgrounds with image files and duplicate the card blocks.
- Change `your@email.com` and the social links near the bottom.

## Publishing
This can be uploaded to a static web host such as GitHub Pages, Netlify, or Cloudflare Pages.
